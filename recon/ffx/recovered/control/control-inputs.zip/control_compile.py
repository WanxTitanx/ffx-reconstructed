"""Run the unmodified legacy recipes in this new Windows staging directory."""
from pathlib import Path
import datetime
import hashlib
import json
import subprocess
import sys
import zipfile

root = Path(__file__).resolve().parent
outputs = ['recon/ffx/c_leaf/build', 'recon/ffx/c_reloc/build', 'recon/ffx/byteproof/build_c']
if any((root / p).exists() for p in outputs):
    raise SystemExit('control output already exists; use a new staging directory')
hashfile = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
vc = Path('C:/Program Files (x86)/Microsoft Visual Studio 11.0')
tools = [vc / 'VC/bin' / n for n in ('cl.exe', 'c1.dll', 'c1xx.dll', 'c2.dll', 'link.exe')]
tools += [vc / 'Common7/IDE' / n for n in ('mspdb110.dll', 'mspdbcore.dll', 'mspdbsrv.exe', 'msvcr110.dll')]
tools += [Path(sys.executable)]
identity = {'started_at': datetime.datetime.now(datetime.timezone.utc).isoformat(),
            'python': sys.version, 'tool_hashes': {str(p): hashfile(p) for p in tools if p.is_file()},
            'inputs': {str(p.relative_to(root)): hashfile(p) for p in root.rglob('*') if p.is_file()},
            'commands': [], 'outputs': {}, 'status': 'running'}
jobs = [('recon/ffx/c_leaf/leaf_build.py', ['--output-dir', str(root / outputs[0])]),
        ('recon/ffx/c_reloc/relocation_build.py', ['--output-dir', str(root / outputs[1])]),
        ('recon/ffx/byteproof/build_memcmp.py', ['--source', str(root/'recon/ffx/ffx_memcmp.c'),
                                             '--output-dir', str(root/outputs[2])])]
with (root / 'control-compile.log').open('wb') as log:
    for helper, args in jobs:
        command = [sys.executable, str(root/helper), *args]
        result = subprocess.run(command, cwd=root, stdout=log, stderr=subprocess.STDOUT)
        identity['commands'].append({'argv': command, 'exit_code': result.returncode})
        if result.returncode:
            identity['status'] = 'failed'
            (root / 'control-receipt.json').write_text(json.dumps(identity, indent=2))
            raise SystemExit(result.returncode)
for name, before in identity['tool_hashes'].items():
    if hashfile(Path(name)) != before:
        raise SystemExit('tool changed during compilation: ' + name)
for name, before in identity['inputs'].items():
    if hashfile(root / name) != before:
        raise SystemExit('input changed during compilation: ' + name)
for rel in outputs:
    for p in (root/rel).rglob('*'):
        if p.is_file():
            identity['outputs'][str(p.relative_to(root))] = hashfile(p)
identity.update(status='complete', finished_at=datetime.datetime.now(datetime.timezone.utc).isoformat())
(root/'control-receipt.json').write_text(json.dumps(identity, indent=2), encoding='utf-8')
with zipfile.ZipFile(root/'control-output.zip', 'x', compression=zipfile.ZIP_DEFLATED) as archive:
    for rel in [*identity['outputs'], 'control-receipt.json', 'control-compile.log']:
        archive.write(root/rel, rel)
print(json.dumps({'status': 'complete', 'outputs': len(identity['outputs']),
                  'zip_bytes': (root/'control-output.zip').stat().st_size}))
