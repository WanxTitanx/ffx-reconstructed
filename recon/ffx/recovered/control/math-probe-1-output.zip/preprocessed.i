#line 1 "package/inputs/src/math/vec3_normalize.c"
#line 1 "package/inputs/include\\ffx_abi.h"







typedef struct FfxFloat4 {
    float x;
    float y;
    float z;
    float w;
} FfxFloat4;

typedef char FfxRequirePointer32[sizeof(void *) == 4 ? 1 : -1];
typedef char FfxRequireFloat32[sizeof(float) == 4 ? 1 : -1];
typedef char FfxRequireFloat4Size[sizeof(FfxFloat4) == 16 ? 1 : -1];

typedef char FfxRequireXOffset[((unsigned int)&(((FfxFloat4 *)0)->x)) == 0 ? 1 : -1];
typedef char FfxRequireYOffset[((unsigned int)&(((FfxFloat4 *)0)->y)) == 4 ? 1 : -1];
typedef char FfxRequireZOffset[((unsigned int)&(((FfxFloat4 *)0)->z)) == 8 ? 1 : -1];
typedef char FfxRequireWOffset[((unsigned int)&(((FfxFloat4 *)0)->w)) == 12 ? 1 : -1];

void __cdecl FFX_Math_Vec3Normalize(FfxFloat4 *destination, const FfxFloat4 *source);

#line 27 "package/inputs/include\\ffx_abi.h"
#line 2 "package/inputs/src/math/vec3_normalize.c"



double __cdecl sqrt(double value);
#pragma intrinsic(sqrt)






void __cdecl FFX_Math_Vec3Normalize(FfxFloat4 *destination, const FfxFloat4 *source)
{
    float length = sqrt(source->x * source->x + source->y * source->y + source->z * source->z);
    if (length > 0.0) {
        float reciprocal = 1.0 / length;
        destination->x = source->x * reciprocal;
        destination->y = reciprocal * source->y;
        destination->z = reciprocal * source->z;
        destination->w = source->w;
    }
}
